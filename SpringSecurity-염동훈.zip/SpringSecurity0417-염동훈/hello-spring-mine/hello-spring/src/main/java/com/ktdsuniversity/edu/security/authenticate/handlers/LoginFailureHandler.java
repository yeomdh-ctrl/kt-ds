package com.ktdsuniversity.edu.security.authenticate.handlers;

import java.io.IOException;

import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.authentication.AuthenticationFailureHandler;

import com.ktdsuniversity.edu.members.dao.MembersDao;
import com.ktdsuniversity.edu.members.vo.request.LoginVO;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class LoginFailureHandler implements AuthenticationFailureHandler{

	private MembersDao membersDao;
	
	public LoginFailureHandler(MembersDao membersDao) {
		this.membersDao = membersDao;
	}
	
	// 로그인을 실패 했을 경우 동작할 코드
	@Override
	public void onAuthenticationFailure(HttpServletRequest request, HttpServletResponse response,
			AuthenticationException exception) throws IOException, ServletException {
		
		// request으로부터 사용자가 입력한 이메일을 받아옴
		String email = request.getParameter("email");
		
		// 비밀번호 틀렸을 때 BadCredentialsException예외를 던짐
		if(exception instanceof BadCredentialsException) {
			// 로그인 실패 횟수 업데이트
			this.membersDao.updateIncreaseLoginFailCount(email);
			// 계정 잠금 여부 업데이트
			this.membersDao.updateBlock(email);
		}
		// 로그인 페이지의 경로를 우리가 만든 경로로 지정
		String loginPagePath = "/WEB-INF/views/members/login.jsp";
		// 받은 요청을 다른 페이지로 넘겨줄 준비
		RequestDispatcher dispatcher = request.getRequestDispatcher(loginPagePath);
		
		// 이메일을 사용자가 입력한 이메일담기
		LoginVO loginVO = new LoginVO();
		loginVO.setEmail(email);
		
		// request에 inputData라는 이름으로 loginVO를 저장
		request.setAttribute("inputData", loginVO);
		
		// 발생한 에러의 메세지
		request.setAttribute("errorMessage", exception.getMessage());
		
		// inputData, errorMessage 를 가지고 로그인 페이지로 이동. 브라우저 주소창은 변화 X
		dispatcher.forward(request, response);
	}
	
}