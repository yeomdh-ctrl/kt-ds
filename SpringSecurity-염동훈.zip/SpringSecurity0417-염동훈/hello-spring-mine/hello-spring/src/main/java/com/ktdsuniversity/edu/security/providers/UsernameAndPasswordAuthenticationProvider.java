package com.ktdsuniversity.edu.security.providers;

import org.jspecify.annotations.Nullable;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.LockedException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;

import com.ktdsuniversity.edu.members.vo.MembersVO;
import com.ktdsuniversity.edu.security.authenticate.service.SecurityPasswordEncoder;
import com.ktdsuniversity.edu.security.user.SecurityUser;

// Spring Security에서 아이디와 비밀번호 일치 검사을 수행
public class UsernameAndPasswordAuthenticationProvider implements AuthenticationProvider{
	
	// 회원 정보 조회
	private UserDetailsService userDetailService;
	
	// 비밀번호 비교
	private PasswordEncoder passwordEncoder;

	public UsernameAndPasswordAuthenticationProvider(UserDetailsService userDetailsService,
			PasswordEncoder passwordEncoder) {
		this.userDetailService = userDetailsService;
		this.passwordEncoder = passwordEncoder;
	}

	// 아이디와 비밀번호가 담긴 authentication을 받아 검증 수행
	@Override
	public @Nullable Authentication authenticate(Authentication authentication) throws AuthenticationException {
		
		// 로그인에 사용된 사용자의 아이디를 가져옴
		String email = authentication.getName();
		// DB에서 해당 이메일을 가진 회원 정보를 통째로 가져옴
		UserDetails userDetails = this.userDetailService.loadUserByUsername(email);
		// 만약 계정이 잠겨있다면 예외 던짐
		if(!userDetails.isAccountNonLocked()) {
			throw new LockedException("아이디 또는 비밀번호가 일치하지 않습니다.");
		}
		// 사용자가 입력한 평문 비밀번호를 가져옴
		String rawPassword = authentication.getCredentials().toString();
		// userDetails를 SecurityUser로 형변환하여, 안에 들어있는 MembersVO를 꺼냄
		MembersVO membersVO = ((SecurityUser) userDetails).getMembersVO();
		// 위에서 만든 passwordEncoder을 사용하기 위해 형변환
		SecurityPasswordEncoder passwordComparator = (SecurityPasswordEncoder) this.passwordEncoder;
		// 입력한 비번, salt, 암호화된 비번 3개를 넣고 일치하는지 확인
		boolean isMatch = passwordComparator.matches(rawPassword, membersVO.getSalt(), userDetails.getPassword());
		// 다르다면 예외 던짐
		if(!isMatch) {
			throw new BadCredentialsException("아이디 또는 비밀번호가 일치하지 않습니다.");
		}
				
		// 모든 인증에 통과할 시 토큰을 반환
		return new UsernamePasswordAuthenticationToken(membersVO, userDetails.getPassword(), userDetails.getAuthorities());
	}

	// 이 클래스는 아이디와 비밀번호를 이용한 로그인 요청만 전문적으로 처리하겠다고 선언
	@Override
	public boolean supports(Class<?> authentication) {
		return authentication.equals(UsernamePasswordAuthenticationToken.class);
	}

}
