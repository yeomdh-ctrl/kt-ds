package com.ktdsuniversity.edu.security.authenticate.service;

import java.util.List;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import com.ktdsuniversity.edu.members.dao.MembersDao;
import com.ktdsuniversity.edu.members.vo.MembersVO;
import com.ktdsuniversity.edu.security.user.SecurityUser;

// Spring Security가 회원 정보를 가져올 때 사용
public class SecurityUserDetailsService implements UserDetailsService{

	// DB에서 회원 데이터를 꺼내올 MembersDao 연결
	private MembersDao membersDao;
	
	public SecurityUserDetailsService(MembersDao membersDao) {
		this.membersDao = membersDao;
	}

	// 로그인을 눌렀을 때 입력한 아이디를 받아오고 입력안하면 UsernameNotFoundException 예외 던짐
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		// 입력받은 아이디를 가지고 회원 정보를 가져옴
		MembersVO loadedUser = this.membersDao.selectMemberByEmail(username);
		// 존재하지 않는 회원일 경우 예외 던짐
		if(loadedUser == null) {
			throw new UsernameNotFoundException("아이디 또는 비밀번호가 일치하지 않습니다.");
		}
		// 회원의 권한을 조회 후 loadedUser에 저장
		List<String> userRole = this.membersDao.selectMemberRolesByEmail(username);
		loadedUser.setRoles(userRole);
		// Spring Security가 식별할 수 있는 형태인 SecurityUser로 loadedUser를 감싼 후 반환
		return new SecurityUser(loadedUser);
	}
	
}
