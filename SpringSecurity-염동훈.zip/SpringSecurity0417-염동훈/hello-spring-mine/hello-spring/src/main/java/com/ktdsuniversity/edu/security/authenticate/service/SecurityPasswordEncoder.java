package com.ktdsuniversity.edu.security.authenticate.service;

import org.jspecify.annotations.Nullable;
import org.springframework.security.crypto.password.PasswordEncoder;

import com.ktdsuniversity.edu.members.helpers.SHA256Util;

// Spring Security의 PasswordEncoder라는 인터페이스를 가져옴
public class SecurityPasswordEncoder implements PasswordEncoder{


	// 스프링이 제공하는 비밀번호만 받아서 암호화하는 메서드
	@Override
	public @Nullable String encode(@Nullable CharSequence rawPassword) {
		return null;
	}

	//입력한 비밀번호와 DB의 비밀번호가 같은지 확인
	@Override
	public boolean matches(@Nullable CharSequence rawPassword, @Nullable String encodedPassword) {
		return false;
	}
	// 사용자가 입력한 비밀번호와 salt를 섞어서 SHA256 방식으로 암호화
	public String encode(String rawPassword, String salt) {
		return SHA256Util.getEncrypt(rawPassword, salt);
	}
	// 입력한 비밀번호 다시 한번 암호화 후 그 결과가 DB에 저장되어 있던 암호문과 똑같은지 비교
	public boolean matches(String rawPassword, String salt, String encodedPassword) {
		return this.encode(rawPassword, salt).equals(encodedPassword);
	}

}
