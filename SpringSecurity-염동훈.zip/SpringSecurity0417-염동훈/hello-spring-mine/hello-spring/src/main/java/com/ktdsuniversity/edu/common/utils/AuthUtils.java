package com.ktdsuniversity.edu.common.utils;

import java.util.List;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import com.ktdsuniversity.edu.members.vo.MembersVO;

public abstract class AuthUtils {

	private AuthUtils() {}
	
	// null이 아닌지 검사
	public static boolean isAuthenticatied() {
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		
		return authentication != null;
	}
	public static MembersVO getPrincipal() {
		if(isAuthenticatied()) {
			Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
			return (MembersVO)authentication.getPrincipal();
		}
		return null;
	}
	// 토큰에서 이메일을 가져오기
	public static String getUsername() {
		if(isAuthenticatied()) {
			return getPrincipal().getEmail();
		}
		return null;
	}
	// 토큰에 권한이 부여되어 있는지 검사
	public static boolean hasAnyRole(String ... roles) {
		if(isAuthenticatied()) {
			List<String> grantedRoles = getPrincipal().getRoles();
			
			for(String role : roles) {
				if(grantedRoles.contains(role)) {
					return true;
				}
			}
		}
		return false;
	}
	
}
