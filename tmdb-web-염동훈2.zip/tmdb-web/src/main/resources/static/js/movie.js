$().ready(function () {
  // "add.file"을 클릭하면 새로운 파일 input과 버튼을 ".attach-files"아래에 추가한다
  $(".attach-files").on("click", ".add-file", function () {
    //   $(".add-file").on("click", function () {
    //새로운 파일이 추가 될 때 마다 기존의 "add-file"을 "del-file"로 변경하고
    // 텍스트는 + 에서 - 로 변경한다.
    $(this)
      .closest(".attach-files")
      .children(".add-file")
      .removeClass("add-file")
      .addClass("del-file")
      .text("-")
      .off("click") // 할당 되어있던 이벤트를 제거한다.
      .on("click", function () {
        // 버튼 왼쪽에 있는 input 태그 삭제, 버튼도 삭제
        $(this).prev().remove();
        $(this).remove();
      });

    // java에서 attachFile 이라는 컬렉션을 리스트로 받아온다. -> WriteVO 수정
    var fileInput = $("<input/>");
    fileInput.attr({
      type: "file",
      name: "attachFile",
    });

    var addButton = $("<button/>");

    addButton.attr("type", "button").addClass("add-file").text("+");

    $(".attach-files").append(fileInput).append(addButton);
	
	
	$("#writeVO").on("submit", function(event){
			event.preventDefault();
			$(this).find(".validation-error").remove();
			var movieId = $("#movieId").val();
			if(!movieId){
				var movieIdErrorMessage = $("<div>");
				movieIdErrorMessage.addClass("validation-error");
				movieIdErrorMessage.text("영화 아이디를 입력해주세요");
				$("#movieId").after(movieIdErrorMessage);
			}
			
			var posterUrl = $("#posterUrl").val();
			if(!posterUrl){
				var posterUrlErrorMessage = $("<div>");
				posterUrlErrorMessage.addClass("validation-error");
				posterUrlErrorMessage.text("포스터 URL을 입력하세요");
				$("#posterUrl").after(posterUrlErrorMessage);
			}
			var title = $("#title").val();
			if(!title){
				var titleErrorMessage = $("<div>");
				titleErrorMessage.addClass("validation-error");
				titleErrorMessage.text("제목을 입력하세요");
				$("#title").after(titleErrorMessage);
			}
			var synopsis = $("#synopsis").val();
			if(!synopsis){
				var synopsisErrorMessage = $("<div>");
				synopsisErrorMessage.addClass("validation-error");
				synopsisErrorMessage.text("시놉시스를 입력하세요");
				$("#synopsis").after(synopsisErrorMessage);
			}
			var state = $("#state").val();
			if(!state){
				var stateErrorMessage = $("<div>");
				stateErrorMessage.addClass("validation-error");
				stateErrorMessage.text("상태를 입력하세요");
				$("#state").after(stateErrorMessage);
			}
			var language = $("#language").val();
			if(!language){
				var languageErrorMessage = $("<div>");
				languageErrorMessage.addClass("validation-error");
				languageErrorMessage.text("언어를 입력하세요");
				$("#language").after(languageErrorMessage);
			}
			
			
			if($(".validation-error").length === 0){
				this.submit();
			}
		}
  });
});