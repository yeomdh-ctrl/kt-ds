package com.ktdsuniversity.edu.config.interceptors;

import org.springframework.web.servlet.HandlerInterceptor;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
/**
 * Endpoint에 접근하기 전 세션이 존재할 경우
 * 컨트롤러가 실행되지 않고 게시글 목록 조회 페이지로 이동
 * page 이동 코드: response.sendRedirect("URL");
 * 로그인, 회원가입, 이메일 중복 검사는 세션이 있으면 게시글 목록으로 이동 
 */
public class IllegalAccessInterceptor implements HandlerInterceptor{
	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
		HttpSession session = request.getSession();
		if(session.getAttribute("__LOGIN_DATA__") != null) {
			response.sendRedirect("/");
			return false;
		}
		return true;
	}

}
