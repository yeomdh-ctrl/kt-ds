package com.ktdsuniversity.edu.genre.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ktdsuniversity.edu.genre.dao.GenreDao;
import com.ktdsuniversity.edu.genre.vo.GenreVO;
import com.ktdsuniversity.edu.genre.vo.response.SearchResultVO;

@Service
public class GenreServiceImpl implements GenreService{
	
	@Autowired
	private GenreDao genreDao;
	
	@Override
	public SearchResultVO findAllGenre() {
		SearchResultVO result = new SearchResultVO();
		List<GenreVO> list = this.genreDao.seletGenreList();
		result.setResult(list);
		return result;
	}

}
