package com.ktdsuniversity.edu.genre.web;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.ktdsuniversity.edu.genre.service.GenreService;
import com.ktdsuniversity.edu.genre.vo.GenreVO;
import com.ktdsuniversity.edu.genre.vo.response.SearchResultVO;

@Controller
public class GenreController {
	@Autowired
	private GenreService genreService;
	
	@GetMapping("/genre")
	public String viewGenrePage(Model model) {
		SearchResultVO result = this.genreService.findAllGenre();
		List<GenreVO> list = result.getResult();
		
		model.addAttribute("result", list);
		
		return "/genre/genreList";
	}

}
