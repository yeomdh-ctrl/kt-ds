package com.ktdsuniversity.edu.members.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ktdsuniversity.edu.members.dao.MembersDao;
import com.ktdsuniversity.edu.members.helpers.SHA256Util;
import com.ktdsuniversity.edu.members.vo.MembersVO;
import com.ktdsuniversity.edu.members.vo.request.RegistVO;

@Service
public class MembersServiceImpl implements MembersService {

	@Autowired
	private MembersDao membersDao;
	
	@Override
	public boolean createNewMember(RegistVO registVO) {
		MembersVO membersVO = this.membersDao.selectMemberByEmail(registVO.getEmail());
		if(membersVO != null) {
			throw new IllegalArgumentException(registVO.getEmail() +"은 이미 사용중인 이메일입니다.");
		}
		String newSalt = SHA256Util.generateSalt();
		String usersPassword = registVO.getPassword();
		
		usersPassword = SHA256Util.getEncrypt(usersPassword, newSalt);
		
		registVO.setSalt(newSalt);
		registVO.setPassword(usersPassword);
		
		int insertCount = this.membersDao.insertNewMember(registVO);
		return insertCount == 1;
	}

	@Override
	public MembersVO findMemberByEmail(String email) {
		MembersVO searchResult = this.membersDao.selectMemberByEmail(email);
		return searchResult;
	}

	@Override
	public boolean deleteMemberByEmail(String email) {
		int deleteCount = this.membersDao.deleteMemberByEmail(email);
		return deleteCount == 1;
	}

}
