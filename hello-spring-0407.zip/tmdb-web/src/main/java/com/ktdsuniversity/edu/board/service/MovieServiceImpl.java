package com.ktdsuniversity.edu.board.service;

import java.io.File;
import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.ktdsuniversity.edu.board.dao.MovieDao;
import com.ktdsuniversity.edu.board.vo.MovieVO;
import com.ktdsuniversity.edu.board.vo.request.WriteVO;
import com.ktdsuniversity.edu.board.vo.response.SearchResultVO;
import com.ktdsuniversity.edu.files.dao.FilesDao;
import com.ktdsuniversity.edu.files.vo.request.UploadVO;

@Service
public class MovieServiceImpl implements MovieService{

	@Autowired
	private MovieDao movieDao;
	
	@Autowired
	private FilesDao filesDao; 

	@Override
	public SearchResultVO findAllMovie() {
		SearchResultVO result = new SearchResultVO();
		int count = this.movieDao.selectMovieCount();
		result.setCount(count);
		if(count==0) {
			return result;
		}
		List<MovieVO> list = this.movieDao.selectMovieList();
		result.setResult(list);
		return result;
	}

	@Override
	public boolean createNewMovie(WriteVO writeVO) {
		int insertCount = this.movieDao.insertNewMovie(writeVO);
		
		List<MultipartFile> attachFiles = writeVO.getAttachFile();
		if(attachFiles !=null && attachFiles.size() > 0) {
			for(int i=0; i < attachFiles.size(); i++) {
				
				// 업로드를 하지 않았는데 했다고 판단한 경우에는 다음 반복으로 넘어가라.
				if (attachFiles.get(i).isEmpty()) {
					continue;
				}
//			for(MultipartFile uploadedFile: attachFiles) {
				// 업로드한 파일이 서버 컴퓨터의 파일 시스템에 저장 되도록 한다.
				File storeFile = new File("C:\\uploadMovies"
										  , attachFiles.get(i).getOriginalFilename());
				// C:\\uploadFiles 폴더가 없으면 생성해라
				if(!storeFile.getParentFile().exists() && !storeFile.getParentFile().isDirectory()) {
					storeFile.getParentFile().mkdirs();
				}
				try {
					attachFiles.get(i).transferTo(storeFile);
					// Files 테이블에 첨부파일 데이터를 insert
					UploadVO uploadVO = new UploadVO();
					
					String filename = attachFiles.get(i).getOriginalFilename();
					String ext = filename.substring(filename.lastIndexOf(".") + 1);
					
					uploadVO.setFileGroupId(writeVO.getMovieId());
					uploadVO.setObfuscateName(filename);
					uploadVO.setDisplayName(filename);
					uploadVO.setExtendName(ext);
					uploadVO.setFileLength(storeFile.length());
					uploadVO.setFilePath(storeFile.getAbsolutePath());
					this.filesDao.insertAttachFile(uploadVO);
					
				} catch (IllegalStateException | IOException e) {
					e.printStackTrace();
				}
			}
		}
		System.out.println("생성된 영화 개수: " + insertCount);
		return insertCount==1;
	}
	@Override
	public boolean deleteMovieByMovieId(String id) {
int deleteCount = this.movieDao.deleteMovieById(id);
		
		List<String> filePaths = this.filesDao.selectFilePathByFileGroupId(id);
		if (filePaths != null && filePaths.size() > 0) {
			for (String path: filePaths) {
				new File(path).delete();
			}
			
			int deleteFileCount = this.filesDao.deleteFileByFileGroupId(id);
			System.out.println("파일 삭제 개수? " + deleteFileCount);
		}
		
		return deleteCount == 1;
	}
	
}
