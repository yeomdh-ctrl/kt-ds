package com.ktdsuniversity.edu.board.service;

import com.ktdsuniversity.edu.board.vo.request.WriteVO;
import com.ktdsuniversity.edu.board.vo.response.SearchResultVO;

public interface MovieService {

	SearchResultVO findAllMovie();

	boolean createNewMovie(WriteVO writeVO);

	boolean deleteMovieByMovieId(String id);

}
