package com.ktdsuniversity.edu.genre.service;

import com.ktdsuniversity.edu.genre.vo.response.SearchResultVO;

public interface GenreService {

	SearchResultVO findAllGenre();

}
