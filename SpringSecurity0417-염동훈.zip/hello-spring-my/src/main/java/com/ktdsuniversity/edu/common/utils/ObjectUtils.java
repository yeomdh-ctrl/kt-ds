package com.ktdsuniversity.edu.common.utils;

public abstract class ObjectUtils {

	private ObjectUtils() {}
	
	// 가변길이파라미터(...)
	public static boolean isNull(Object ... object) {
		for (Object obj : object) {
			if (obj == null) {
				return true;
			}
		}
		return false;
	}
	
	public static boolean isNotNull(Object ... object) {
		for (Object obj : object) {
			if (obj == null) {
				return false;
			}
		}
		return true;
	}
	
}
