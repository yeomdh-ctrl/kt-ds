package com.ktdsuniversity.edu.replies.vo.response;

public class UpdateResultVO {

	private String replyId;
	private boolean update;

	public boolean getUpdate() {
		return update;
	}

	public void setUpdate(boolean update) {
		this.update = update;
	}

	public String getReplyId() {
		return replyId;
	}

	public void setReplyId(String replyId) {
		this.replyId = replyId;
	}

}
