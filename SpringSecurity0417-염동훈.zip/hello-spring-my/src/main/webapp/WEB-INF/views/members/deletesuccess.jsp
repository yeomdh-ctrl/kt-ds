<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<jsp:include page="/WEB-INF/views/templates/header.jsp">
<jsp:param value="회원 탈퇴" name="title"/>
<jsp:param value="<script type='text/javascript' src='/js/members.js'></script>" name="script"/>
</jsp:include>
	<h1>탈퇴가 완료됐습니다. 다음에 다시 만나요!</h1>
<jsp:include page="/WEB-INF/views/templates/footer.jsp"></jsp:include>