<%@ page language="java" contentType="text/html; charset=UTF-8"
pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8" />
    <title>회원가입</title>
    <link rel="stylesheet" type="text/css" href="/css/hello-spring.css" />
  </head>
  <body>
    <h1>회원가입</h1>
    <form method="post" action="/regist">
      <div class="grid">
        <label for="email">이메일</label>
        <input
          id="email"
          type="email"
          id="email"
          name="email"
          placeholder="이메일을 입력하세요"
        />
        <label for="name">이름</label>
        <input
          id="name"
          type="text"
          name="name"
          placeholder="이름을 입력하세요"
        />
        <label for="password">비밀번호</label>
        <input
          id="password"
          type="password"
          name="password"
          placeholder="비밀번호를 입력하세요"
        />
        <label for="passwordConfirm">비밀번호확인</label>
        <input id="passwordConfirm" type="password" name="passwordConfirm" />
      </div>
    </form>
  </body>
</html>
