package com.ktdsuniversity.edu.board.vo.request;

// WriteVO의 기능에서 id만 추가한 것이므로 같은 정보를 공유하는 것은 상속을 시켜서 확장시킨다.
public class UpdateVO extends WriteVO{
	
	private String id; //UPDATE ~ WHERE에 사용할 변수

	public String getId() {
		return this.id;
	}
	public void setId(String id) {
		this.id = id;
	}	
}
