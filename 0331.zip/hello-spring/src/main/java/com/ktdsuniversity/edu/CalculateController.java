package com.ktdsuniversity.edu;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class CalculateController {
	/**
	 * <pre>
	 * 엔드포인트 = /calc
	 * 반환시키는 템플릿 이름 = calc.jsp
	 * 템플릿으로 반환 시키는 데이터
	 * 	- 1. firstNum
	 *  - 2. secondNum
	 *  - 3. result(firstNum + secondNum 의 결과)
	 * 템플릿의 결과
	 *  - <div>
	 *  	<span>firstNum의 값</span>
	 *  	<span>secondNum의 값</span>
	 *  	<span>result의 값</span>
	 *    </div>
	 * </pre>
	 */
	@GetMapping("/calc")
	public String viewCalculateController(Model model) {
		model.addAttribute("firstNum","5");
		model.addAttribute("secondNum","6");
		model.addAttribute("result","11");
		System.out.println(model);
		return "calc";
	}
	/**
	 * <pre>
	 * Browser에서 EndPoint로 파라미터를 보내는 3가지 방법
	 * 1. Query String Parameter => endpoint 뒤에 "?"를 이용해서 보내는 방법
	 *  ex) /endpoint?key=value&key2=value2&....
	 *  ex) /calc2?firstNum=5&secondNum=6
	 * 2. Form Parameter => <form></form> 를 이용해서 보내는 방법
	 *  ex) <form action="/calc2">
	 *  		<input name="key" value="value"/>
	 *  		 <select name="key2">
	 *  			<option value="value2">Text</option>
	 *  			<option value="value3">Other Text</option>
	 *  		</select> 
	 *  		<textarea name="key3">Value</textarea>
	 *  	</form>
	 * 3. Request Body => Http Request Body 영역에 파라미터를 보내는 방법
	 *   ex) 파일 업로드, AJAX 요청
	 * 4. Hybrid (Alternative - Complex)
	 * 		=> Query String Parameter + Form Parameter
	 * 		=> Query String Parameter + Request Body
	 * * Spring 전용 Parameter
	 * 		=> Path(URL) Variable
	 * 			=> Query String Parameter 외의 파라미터를 URL로 보내는 방법
	 * 
	 * Spring Endpoint 에서 파라미터를 받아오는 4가지 방법
	 * 1. HttpServletRequest 객체를 이용하는 방법 (스프링에서는 잘 사용되지 않는다.)
	 * 		=> Query String Parameter, Form Parameter, Request Body 취득 가능
	 * 		=> HTTP Header 정보 취득 가능, 요청자의 IP 취득 가능
	 * 		=> Endpoint를 호출한 위치(Referrer)도 취득 가능
	 * 2. @RequestParam 을 이용하는 방법 (종종 사용된다. 파라미터의 개수가 적을 때 사용 - 2개 이하)
	 * 		=> Query String Parameter, Form Parameter 취득 가능
	 * 3. @ModelAttribute 를 이용하는 방법 (가장 많이 사용된다. 파라미터의 개수가 많을 때 사용)
	 * 		=> Command Object, @ModelAttribute Annotation은 생략 가능.
	 * 		=> Query String Parameter, Form Parameter 취득 가능
	 * 4. @RequestBody 를 이용하는 방법 (API-AJAX 기반의 프로젝트에서 주로 사용된다.)
	 * 		=> Request Body 취득 가능
	 * 	번외) @PathVariable 를 이용하는 방법 (가장 많이 사용된다. Path(URL) Variable 취득)
	 * </pre>
	 * @return
	 */
	// calc2?f=1&s=3
	// http://192.168.211.15:8080/calc2?f=1&s=3
	// required = false, defaultValue = "0" => RequestParam은 필수로 설정되어 있으므로 Parameter의 값을 url에 전달하지 않으면 0 + 0 = 0 으로 나오도록 하는 방법
	// 이러면 파라미터의 값을 입력하지 않거나 하나만 입력해도 에러가 발생하지 않음
	@GetMapping("/calc2")
	public String viewParamCalcPage(@RequestParam(required = false, defaultValue = "0") int f, @RequestParam(required = false, defaultValue = "0") int s, Model model) {
		int result = f + s;
		model.addAttribute("firstNum",f);
		model.addAttribute("secondNum",s);
		model.addAttribute("result",result);
		return "calc";
	}
}
