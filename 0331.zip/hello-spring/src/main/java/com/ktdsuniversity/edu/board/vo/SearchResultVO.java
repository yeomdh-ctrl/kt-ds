package com.ktdsuniversity.edu.board.vo;
/**
 * 게시글 검색 결과를 담고 있는 클래스
 * 게시글 목록
 * 게시글 개수
 */

import java.util.List;

public class SearchResultVO {
	private List<BoardVO> result;
	private int count;
	
	
	public List<BoardVO> getResult() {
		return this.result;
	}
	public void setResult(List<BoardVO> result) {
		this.result = result;
	}
	public int getCount() {
		return this.count;
	}
	public void setCount(int count) {
		this.count = count;
	}
}
