$().ready(function () {
  alert("!!!!");
});
