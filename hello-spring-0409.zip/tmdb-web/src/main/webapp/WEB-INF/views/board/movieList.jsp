<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html>
<head>
    <title>TMDB 영화</title>
    <link rel="stylesheet" type="text/css" href="/css/hello-spring.css" />
</head>
<body>
    <h1>TMDB 영화</h1>
    <div>총 ${searchCount}개의 영화가 검색되었습니다.</div>
    <table class="grid">
        <thead>
          <tr>
            <th>영화 아이디</th>
            <th>포스터 URL</th>
            <th>타이틀</th>
            <th>관람 등급</th>
            <th>개봉일</th>
            <th>개봉국</th>
            <th>상영시간</th>
            <th>영화소개</th>
            <th>시놉시스</th>
            <th>원제</th>
            <th>개봉상태</th>
            <th>언어</th>
            <th>예산</th>
            <th>수익</th>
        </tr>
        </thead>
        <tbody>
          <c:choose>
            <c:when test="${not empty searchResult}">
                <c:forEach items="${searchResult}" var="movie">
                  <tr>
                    <td>${movie.movieId}</td>
                    <td>${movie.posterUrl}</td>
                    <td>${movie.title}</td>
                    <td>${movie.movieRating}</td>
                    <td>${movie.openDate}</td>
                    <td>${movie.openCountry}</td>
                    <td>${movie.runningTime}</td>
                    <td>${movie.introduce}</td>
                    <td>${movie.synopsis}</td>
                    <td>${movie.originalTitle}</td>
                    <td>${movie.state}</td>
                    <td>${movie.language}</td>
                    <td>${movie.budget}</td>
                    <td>${movie.profit}</td>
                </tr>
                </c:forEach>            
            </c:when>
            <c:otherwise>
                <tr>
                    <td colspan="15">검색된 데이터가 없습니다</td>
                </tr>
            </c:otherwise>
          </c:choose>
        </tbody>
      </table>
    <!-- <div>영화 아이디: ${searchResult[0].movieId}</div>
    <div>포스터 URL: ${searchResult[0].posterUrl}
        <img src="/file/${file.fileGroupId}/${file.fileNum}" alt="${file.displayName}"/>
    </div>
    <div>타이틀: ${searchResult[0].title}</div>
    <div>관람 등급: ${searchResult[0].movieRating}</div>
    <div>개봉일: ${searchResult[0].openDate}</div>
    <div>개봉국: ${searchResult[0].openCountry}</div>
    <div>상영시간: ${searchResult[0].runningTime}</div>
    <div>영화소개: ${searchResult[0].introduce}</div>
    <div>시놉시스: ${searchResult[0].synopsis}</div>
    <div>원제: ${searchResult[0].originalTitle}</div>
    <div>개봉상태: ${searchResult[0].state}</div>
    <div>언어: ${searchResult[0].language}</div>
    <div>예산: ${searchResult[0].budget}</div>
    <div>수익: ${searchResult[0].profit}</div> -->
    <div class="btn-group">
        <div class="right-align">
          <a href="/write">영화 등록</a>
        </div>
      </div>
</body>
</html>