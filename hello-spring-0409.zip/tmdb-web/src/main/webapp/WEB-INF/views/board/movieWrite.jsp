<%@ page language="java" contentType="text/html; charset=UTF-8"
pageEncoding="UTF-8"%> <%@ taglib prefix="form"
uri="http://www.springframework.org/tags/form" %>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8" />
    <script type="text/javascript" src="/js/jquery-4.0.0.slim.min.js"></script>
    <script type="text/javascript" src="/js/movie.js"></script>
    <link rel="stylesheet" type="text/css" href="/css/hello-spring.css" />
    <title>영화 등록</title>
  </head>
  <body>
    <h1>영화 등록</h1>

    <form:form
      modelAttribute="writeVO"
      method="post"
      action="/write"
      enctype="multipart/form-data"
    >
      <div class="grid write">
        <label for="movieId">영화 ID</label>
        <div class="input-div">
          <input
            id="movieId"
            type="text"
            name="movieId"
            value="${inputData.movieId}"
          />
          <form:errors
            path="movieId"
            cssClass="validation-error"
            element="div"
          />
        </div>

        <label for="posterUrl">포스터 URL</label>
        <div class="input-div">
          <input
            id="posterUrl"
            type="text"
            name="posterUrl"
            value="${inputData.posterUrl}"
          />
          <form:errors
            path="posterUrl"
            cssClass="validation-error"
            element="div"
          />
        </div>

        <label for="attach-files">첨부파일</label>
        <div id="attach-files" class="attach-files">
          <input type="file" name="attachFile" />
        </div>

        <label for="title">타이틀</label>
        <div class="input-div">
          <input
            id="title"
            type="text"
            name="title"
            value="${inputData.title}"
          />
          <form:errors path="title" cssClass="validation-error" element="div" />
        </div>

        <label for="movieRating">관람 등급</label>
        <input id="movieRating" type="text" name="movieRating" />

        <label for="openDate">개봉일</label>
        <input id="openDate" type="date" name="openDate" />

        <label for="openCountry">개봉국</label>
        <input id="openCountry" type="text" name="openCountry" />

        <label for="runningTime">상영시간</label>
        <input id="runningTime" type="number" name="runningTime" />

        <label for="introduce">영화 소개</label>
        <textarea name="introduce" id="introduce"></textarea>

        <label for="synopsis">시놉시스</label>
        <div class="input-div">
          <input name="synopsis" id="synopsis" value="${inputData.synopsis}" />
          <form:errors
            path="synopsis"
            cssClass="validation-error"
            element="div"
          />
        </div>

        <label for="originalTitle">원제</label>
        <input id="originalTitle" type="text" name="originalTitle" />

        <label for="state">개봉상태</label>
        <div class="input-div">
          <input
            id="state"
            type="text"
            name="state"
            value="${inputData.state}"
          />
          <form:errors path="state" cssClass="validation-error" element="div" />
        </div>

        <label for="language">언어</label>
        <div class="input-div">
          <input
            id="language"
            type="text"
            name="language"
            value="${inputData.language}"
          />
          <form:errors
            path="language"
            cssClass="validation-error"
            element="div"
          />
        </div>

        <label for="budget">예산</label>
        <input id="budget" type="number" name="budget" />

        <label for="profit">수익</label>
        <input id="profit" type="number" name="profit" />

        <div class="btn-group">
          <div class="right-align">
            <input type="submit" value="저장" />
          </div>
        </div>
      </div>
    </form:form>
  </body>
</html>
