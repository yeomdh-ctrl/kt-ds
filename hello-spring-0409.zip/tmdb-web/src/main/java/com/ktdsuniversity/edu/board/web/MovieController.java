package com.ktdsuniversity.edu.board.web;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.ktdsuniversity.edu.board.service.MovieService;
import com.ktdsuniversity.edu.board.vo.MovieVO;
import com.ktdsuniversity.edu.board.vo.request.WriteVO;
import com.ktdsuniversity.edu.board.vo.response.SearchResultVO;

import jakarta.validation.Valid;

@Controller
public class MovieController {

    @Autowired
    private MovieService movieService;
    
    @GetMapping("/list")
    public String viewListPage(Model model){
		
		SearchResultVO searchResult = this.movieService.findAllMovie();
		
		List<MovieVO> list = searchResult.getResult();
		
		int searchCount = searchResult.getCount();
		
		model.addAttribute("searchResult", list);
		model.addAttribute("searchCount", searchCount);
		
		return "board/movieList";
	}
    @GetMapping("/write")
	public String viewWritePage() {
		return "board/movieWrite";
	}
	
	@PostMapping("/write")
	public String doWriteAction(@Valid @ModelAttribute WriteVO writeVO,
								BindingResult bindingResult, Model model) {
		if(bindingResult.hasErrors()) {
			model.addAttribute("inputData", writeVO);
			return "board/movieWrite";
		}
		
		
		System.out.println(writeVO.getMovieId());
		System.out.println(writeVO.getPosterUrl());
		System.out.println(writeVO.getTitle());
		System.out.println(writeVO.getMovieRating());
		System.out.println(writeVO.getOpenDate());
		System.out.println(writeVO.getOpenCountry());
		System.out.println(writeVO.getRunningTime());
		System.out.println(writeVO.getIntroduce());
		System.out.println(writeVO.getSynopsis());
		System.out.println(writeVO.getOriginalTitle());
		System.out.println(writeVO.getState());
		System.out.println(writeVO.getLanguage());
		System.out.println(writeVO.getBudget());
		System.out.println(writeVO.getProfit());
		
		boolean createResult = this.movieService.createNewMovie(writeVO);
		
		System.out.println("생성결과: " + createResult);
		
		return "redirect:/list";
	}
	@GetMapping("/delete")
	public String doDeleteAction(@RequestParam String id) {

		boolean deleteResult = this.movieService.deleteMovieByMovieId(id);
		System.out.println("삭제 결과? " + deleteResult);
		return "redirect:/list";
	}
  
    
}