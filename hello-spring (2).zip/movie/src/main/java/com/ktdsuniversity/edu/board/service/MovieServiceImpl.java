package com.ktdsuniversity.edu.board.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ktdsuniversity.edu.board.dao.MovieDao;
import com.ktdsuniversity.edu.board.vo.MovieVO;
import com.ktdsuniversity.edu.board.vo.request.WriteVO;
import com.ktdsuniversity.edu.board.vo.response.SearchResultVO;
@Service
public class MovieServiceImpl implements MovieService{

	@Autowired
	private MovieDao movieDao;

	@Override
	public SearchResultVO findAllMovie() {
		SearchResultVO result = new SearchResultVO();
		int count = this.movieDao.selectMovieCount();
		result.setCount(count);
		if(count==0) {
			return result;
		}
		List<MovieVO> list = this.movieDao.selectMovieList();
		result.setResult(list);
		return result;
	}

	@Override
	public boolean createNewMovie(WriteVO writeVO) {
		int insertCount = this.movieDao.insertNewMovie(writeVO);
		System.out.println("생성된 영화 개수: " + insertCount);
		return insertCount==1;
	}
	
}
