<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8" />
    <link rel="stylesheet" type="text/css" href="/css/hello-spring.css" />
    <title>영화 등록</title>
  </head>
  <body>
    <h1>영화 등록</h1>
    <form method="post" action="/write">
      <div class="grid write">
        <label for="movieId">영화 ID</label>
        <input id="movieId" type="text" name="movieId" placeholder="영화id를 입력하세요." />

        <label for="posterUrl">포스터 URL</label>
        <input id="posterUrl" type="text" name="posterUrl" placeholder="포스터URL을 입력하세요." />

        <label for="title">타이틀</label>
        <input id="title" type="text" name="title"  />

        <label for="movieRating">관람 등급</label>
        <input id="movieRating" type="text" name="movieRating" />

        <label for="openDate">개봉일</label>
        <input id="openDate" type="date" name="openDate"/>

        <label for="openCountry">개봉국</label>
        <input id="openCountry" type="text" name="openCountry" />

        <label for="runningTime">상영시간</label>
        <input id="runningTime" type="number" name="runningTime" />

        <label for="introduce">영화 소개</label>
        <textarea name="introduce" id="introduce" ></textarea>

        <label for="synopsis">시놉시스</label>
        <textarea name="synopsis" id="synopsis" ></textarea>

        <label for="originalTitle">원제</label>
        <input id="originalTitle" type="text" name="originalTitle" />

        <label for="state">개봉상태</label>
        <input id="movieState" type="text" name="movieState" />

        <label for="language">언어</label>
        <input id="language" type="text" name="language"  />

        <label for="budget">예산</label>
        <input id="budget" type="number" name="budget"  />

        <label for="profit">수익</label>
        <input id="profit" type="number" name="profit" />

        <div class="btn-group">
          <div class="right-align">
            <input type="submit" value="저장" />
          </div>
        </div>
      </div>
    </form>
  </body>
</html>
