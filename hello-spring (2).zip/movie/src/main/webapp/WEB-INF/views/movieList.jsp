<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <title>TMDB 영화</title>
</head>
<body>
    <h1>TMDB 영화</h1>
    <div>총 ${searchCount}개의 영화가 검색되었습니다.</div>
    <div>영화 아이디: ${searchResult[0].movieId}</div>
    <div>포스터 URL: ${searchResult[0].posterUrl}</div>
    <div>타이틀: ${searchResult[0].title}</div>
    <div>관람 등급: ${searchResult[0].movieRating}</div>
    <div>개봉일: ${searchResult[0].openDate}</div>
    <div>개봉국: ${searchResult[0].openCountry}</div>
    <div>상영시간: ${searchResult[0].runningTime}</div>
    <div>영화소개: ${searchResult[0].introduce}</div>
    <div>시놉시스: ${searchResult[0].synopsis}</div>
    <div>원제: ${searchResult[0].originalTitle}</div>
    <div>개봉상태: ${searchResult[0].state}</div>
    <div>언어: ${searchResult[0].language}</div>
    <div>예산: ${searchResult[0].budget}</div>
    <div>수익: ${searchResult[0].profit}</div>
</body>
</html>