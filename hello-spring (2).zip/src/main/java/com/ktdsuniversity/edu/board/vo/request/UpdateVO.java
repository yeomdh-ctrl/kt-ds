package com.ktdsuniversity.edu.board.vo.request;

import java.util.List;

// WriteVO의 기능에서 id만 추가한 것이므로 같은 정보를 공유하는 것은 상속을 시켜서 확장시킨다.
public class UpdateVO extends WriteVO{
	
	private List<Integer> deleteFileNum;
	
	public List<Integer> getDeleteFileNum() {
		return this.deleteFileNum;
	}
	public void setDeleteFileNum(List<Integer> deleteFileNum) {
		this.deleteFileNum = deleteFileNum;
	}	
}
