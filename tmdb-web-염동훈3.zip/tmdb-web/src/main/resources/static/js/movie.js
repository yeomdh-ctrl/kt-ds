$().ready(function () {
  $(".attach-files").on("click", ".add-file", function () {
    $(this)
      .closest(".attach-files")
      .children(".add-file")
      .removeClass("add-file")
      .addClass("del-file")
      .text("-")
      .off("click")
      .on("click", function () {
        $(this).prev().remove();
        $(this).remove();
      });

    var fileInput = $("<input/>");
    fileInput.attr({
      type: "file",
      name: "attachFile",
    });

    var addButton = $("<button/>");
    addButton.attr("type", "button").addClass("add-file").text("+");

    $(".attach-files").append(fileInput).append(addButton);
  });

  $("#writeVO").on("submit", function (event) {
    event.preventDefault();
    $(this).find(".validation-error").remove();

    var movieId = $("#movieId").val();
    if (!movieId) {
      var movieIdErrorMessage = $("<div>");
      movieIdErrorMessage.addClass("validation-error");
      movieIdErrorMessage.text("영화 아이디를 입력해주세요");
      $("#movieId").after(movieIdErrorMessage);
    }

    var posterUrl = $("#posterUrl").val();
    if (!posterUrl) {
      var posterUrlErrorMessage = $("<div>");
      posterUrlErrorMessage.addClass("validation-error");
      posterUrlErrorMessage.text("포스터 URL을 입력하세요");
      $("#posterUrl").after(posterUrlErrorMessage);
    }

    var title = $("#title").val();
    if (!title) {
      var titleErrorMessage = $("<div>");
      titleErrorMessage.addClass("validation-error");
      titleErrorMessage.text("제목을 입력하세요");
      $("#title").after(titleErrorMessage);
    }

    var synopsis = $("#synopsis").val();
    if (!synopsis) {
      var synopsisErrorMessage = $("<div>");
      synopsisErrorMessage.addClass("validation-error");
      synopsisErrorMessage.text("시놉시스를 입력하세요");
      $("#synopsis").after(synopsisErrorMessage);
    }

    var state = $("#state").val();
    if (!state) {
      var stateErrorMessage = $("<div>");
      stateErrorMessage.addClass("validation-error");
      stateErrorMessage.text("상태를 입력하세요");
      $("#state").after(stateErrorMessage);
    }

    var language = $("#language").val();
    if (!language) {
      var languageErrorMessage = $("<div>");
      languageErrorMessage.addClass("validation-error");
      languageErrorMessage.text("언어를 입력하세요");
      $("#language").after(languageErrorMessage);
    }

    if ($(".validation-error").length === 0) {
      this.submit();
    }
  });
});
