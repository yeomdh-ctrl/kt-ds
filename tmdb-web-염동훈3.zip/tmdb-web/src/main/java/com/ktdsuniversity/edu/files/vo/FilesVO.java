package com.ktdsuniversity.edu.files.vo;

public class FilesVO {

}
