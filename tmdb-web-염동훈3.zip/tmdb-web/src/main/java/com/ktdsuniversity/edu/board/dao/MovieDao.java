package com.ktdsuniversity.edu.board.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.ktdsuniversity.edu.board.vo.MovieVO;
import com.ktdsuniversity.edu.board.vo.request.WriteVO;
@Mapper
public interface MovieDao {

	int selectMovieCount();

	List<MovieVO> selectMovieList();

	int insertNewMovie(WriteVO writeVO);

}
