package com.ktdsuniversity.edu.board.vo.response;

import java.util.List;

import com.ktdsuniversity.edu.board.vo.MovieVO;

public class SearchResultVO {
	private int count;
	private List<MovieVO> result;
	public int getCount() {
		return this.count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public List<MovieVO> getResult() {
		return this.result;
	}
	public void setResult(List<MovieVO> result) {
		this.result = result;
	}
	
	

}
