package com.ktdsuniversity.edu.security.authenticate.oauth;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.oauth2.client.userinfo.DefaultOAuth2UserService;
import org.springframework.security.oauth2.client.userinfo.OAuth2UserRequest;
import org.springframework.security.oauth2.client.userinfo.OAuth2UserService;
import org.springframework.security.oauth2.core.OAuth2AuthenticationException;
import org.springframework.security.oauth2.core.user.OAuth2User;

import com.ktdsuniversity.edu.members.dao.MembersDao;
import com.ktdsuniversity.edu.members.vo.MembersVO;
import com.ktdsuniversity.edu.members.vo.request.OAuthMemberVO;
import com.ktdsuniversity.edu.members.vo.request.RegistVO;

// OAuth를 통해 회원을 조회하는 인터페이스
public class HelloSpringOAuthService implements OAuth2UserService<OAuth2UserRequest, OAuth2User> {
	
	private static final Logger logger = LoggerFactory.getLogger(HelloSpringOAuthService.class);
	
	private MembersDao membersDao;
	
	public HelloSpringOAuthService (MembersDao membersDao) {
		this.membersDao = membersDao;
		}
	



	/**
	 * /oauth2/authorization/naver or google을 통해 로그인 한 이후 수행되는 메소드
	 * naver 또는 구글에서 redirect-uri로 응답을 돌려줄 때 실행
	 * @param userRequest oauth 서비스 제공자(네이버, 구글)에게 개인정보를 요청하는 객체
	 * 		1. authorization-uri 호출해서 oauth 인증 수행
	 * 		2. 인증 성공 후 token-uri 호출해서 oauth token 발급
	 * 		3. 발급받은 token을 이용해 user-info-uri를 호출해서 사용자 정보 취득
	 * @return OAuth2User 서비스 제공자로부터 취득한 사용자의 정보를 이용해 인증 정보 생성
	 */
	@Override
	public OAuth2User loadUser(OAuth2UserRequest userRequest)
			throws OAuth2AuthenticationException {
		
		// userRequest를 통해 개인정보 취득
		// OAuth2UserService의 기본 객체 생성 후 userRequest 전달
		OAuth2UserService<OAuth2UserRequest, OAuth2User> userService = new DefaultOAuth2UserService();
		OAuth2User oauthResult = userService.loadUser(userRequest);
		
		
		// yml에 적은 registration의 id(naver)을 가져옴
		String registrationId = userRequest.getClientRegistration().getRegistrationId();
		MembersVO oauthMember = null;
		OAuth2User oauth2Principal = null;
		if(registrationId.equals("naver")) {
			//OAuth 전용 인증 객체 생성해서 반환
			oauthMember = new MembersVO();
			oauth2Principal = new NaverOAuthUserDetails(oauthMember, oauthResult.getAttributes());
			
		}
		else if (registrationId.equals("google")) {
			oauthMember = new MembersVO();
			oauth2Principal = new GoogleOAuthUserDetails(oauthMember, oauthResult.getAttributes());
			
		}
		// OAuth 회원의 정보를 DB에 Insert
		// 이미 존재하는 회원이라면 Insert 하지 않음
		if(oauthMember != null) {
			boolean isGuest = this.membersDao.selectMemberByEmail(oauthMember.getEmail()) == null;
			
			if(isGuest) {
				RegistVO registVO = new RegistVO();
				registVO.setEmail(oauthMember.getEmail());
				registVO.setName(oauthMember.getName());
				registVO.setPassword("NONE");
				registVO.setSalt("NONE");
				
				this.membersDao.insertNewMember(registVO);
			}
			
			OAuthMemberVO oauthMemberVO = new OAuthMemberVO();
			oauthMemberVO.setEmail(oauthMember.getEmail());
			oauthMemberVO.setName(oauthMember.getName());
			oauthMemberVO.setRegistrationId(registrationId);
			boolean isNewOAuth = this.membersDao.selectOAuthMemberByEmailAndRegistrationId(oauthMemberVO) == null;
			if(isNewOAuth) {
				this.membersDao.insertNewOAuthMember(oauthMemberVO);
			}
		}
		
		logger.debug(oauthResult.toString());
		
		return oauth2Principal;
	};
}
