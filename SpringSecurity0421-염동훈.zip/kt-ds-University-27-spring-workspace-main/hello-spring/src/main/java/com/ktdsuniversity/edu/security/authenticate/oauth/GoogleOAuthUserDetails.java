package com.ktdsuniversity.edu.security.authenticate.oauth;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.oauth2.core.user.OAuth2User;

import com.ktdsuniversity.edu.members.vo.MembersVO;
import com.ktdsuniversity.edu.security.user.SecurityUser;

public class GoogleOAuthUserDetails extends SecurityUser implements OAuth2User{
	
	private static final Logger logger = LoggerFactory.getLogger(HelloSpringOAuthService.class);
	
	private Map<String, Object> oauthResult;
	
	public GoogleOAuthUserDetails(MembersVO membersVO, Map<String, Object> oauthResult) {
		super(membersVO);
		this.oauthResult = oauthResult;
		membersVO.setEmail(this.oauthResult.get("email").toString());
		membersVO.setName(this.oauthResult.get("given_name").toString());
		List<String> userRoles = new ArrayList<>();
		userRoles.add("RL-20260414-000003");
		membersVO.setRoles(userRoles);
	}
	
	public String getEmail() {
		return super.getMembersVO().getEmail();
	}

	@Override
	public Map<String, Object> getAttributes() {
		return this.oauthResult;
	}

	@Override
	public String getName() {
		return super.getMembersVO().getName();
	}

}
