package com.ktdsuniversity.edu.security.authenticate.oauth;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.security.oauth2.core.user.OAuth2User;

import com.ktdsuniversity.edu.members.vo.MembersVO;
import com.ktdsuniversity.edu.security.user.SecurityUser;

public class NaverOAuthUserDetails extends SecurityUser implements OAuth2User{

	private static final long serialVersionUID = -7781093686223372145L;
	
	private Map<String, Object> oauthResult;
	
	public NaverOAuthUserDetails(MembersVO membersVO, Map<String, Object> oauthResult) {
		// membersVO를 SecurityUser에 전달해준다.
		super(membersVO);
		this.oauthResult = (Map<String, Object>) oauthResult.get("response");
		
		membersVO.setEmail(this.oauthResult.get("email").toString());
		membersVO.setName(this.oauthResult.get("name").toString());
		List<String> userRoles = new ArrayList<>();
		userRoles.add("RL-20260414-000003");
		membersVO.setRoles(userRoles);
	}
	
	public String getEmail() {
		return super.getMembersVO().getEmail();
	}
	
	@Override
	public Map<String, Object> getAttributes() {
		return oauthResult;
	}

	@Override
	public String getName() {
		return super.getMembersVO().getName();
	}
	
}
