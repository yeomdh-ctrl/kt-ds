package com.ktdsuniversity.edu.board.web;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ktdsuniversity.edu.board.enums.ReadType;
import com.ktdsuniversity.edu.board.service.BoardService;
import com.ktdsuniversity.edu.board.vo.BoardVO;
import com.ktdsuniversity.edu.board.vo.request.SearchListVO;
import com.ktdsuniversity.edu.board.vo.request.UpdateVO;
import com.ktdsuniversity.edu.board.vo.request.WriteVO;
import com.ktdsuniversity.edu.board.vo.response.SearchResultVO;
import com.ktdsuniversity.edu.common.utils.AuthUtils;
import com.ktdsuniversity.edu.exceptions.HelloSpringApiException;
import com.ktdsuniversity.edu.members.vo.MembersVO;

import jakarta.validation.Valid;

@Controller
public class BoardApiController {

	private static final Logger logger = LoggerFactory.getLogger(BoardApiController.class);
	
	/**
	 * 빈 컨테이너에 들어있는 객체 중 타입이 일치하는 객체를 할당 받는다.
	 */
	@Autowired
	private BoardService boardService;
	
	// http://192.168.211.11:8080/?pageNo=0&listSize=10&searchType=&searchKeyword
	@ResponseBody
	@GetMapping("/api/articles")
	public Map<String, Object> viewListPage(SearchListVO searchListVO) {
		
		SearchResultVO searchResult = this.boardService.findAllBoard(searchListVO);
		
		Map<String, Object> jsonResult = new HashMap<>();
		jsonResult.put("result", searchResult);
		jsonResult.put("pagination", searchListVO);
		
		return jsonResult;
	}

	@PreAuthorize("isAuthenticated()")
	// 게시글을 등록하는 EndPoint
	@ResponseBody
	@PostMapping("/api/articles")
	// WriteVO 에 multipartFile이 있으면 RequestBody 사용 불가
	public Map<String, Boolean> doWriteAction(@Valid WriteVO writeVO,
								// @Valid의 결과를 받아오는 파라미터.
								// 반드시 @Valid 파라미터 이후에 작성!
							    BindingResult bindingResult,
							    // Spring Security의 인증 토큰
							    Authentication authentication) {
		// 사용자의 입력값을 검증 했을 때, 에러가 있다면
		if (bindingResult.hasErrors()) {
			throw new HelloSpringApiException("글쓰기 실패", HttpStatus.BAD_REQUEST.value(), bindingResult.getFieldErrors());
		}
		
		MembersVO loginUser = AuthUtils.getPrincipal();
		// 로그인 데이터(__LOGIN_DATA__)에서 로그인 한 사용자의 이메일을 가져온다.
		writeVO.setEmail(loginUser.getEmail());

		
		// create, update, delete => 성공/실패 여부 반환.
		boolean createResult = this.boardService.createNewBoard(writeVO);
		
		// Map을 Json으로 바꿔주기 위해서 작성
		return Map.of("result", createResult);

	}
	
	// 게시글 내용 조회.
	@PreAuthorize("isAuthenticated()")
	@ResponseBody
	@GetMapping("/api/articles/{articleId}")
	public BoardVO viewDetailPage(@PathVariable String articleId) {
		
		// articleId로 데이터베이스에서 게시글을 조회한다.
		// 조회할 때 조회수가 하나 증가해야 한다.
		BoardVO findResult = this.boardService.findBoardByArticleId(articleId, ReadType.VIEW);
		return findResult;
	}
	
	/**
	 * 삭제하려는 게시글의 작성자가 본인이거나 슈퍼관리자, 관리자일 경우만 삭제 수행
	 * 그렇지 않을 경우 HelloSpringException을 던진다.
	 * @param id
	 * @return
	 */
	@PreAuthorize("isAuthenticated()")
	@ResponseBody
	@DeleteMapping("/api/articles/{id}") // 자원을 지울 때 사용할 수 있는 DeleteMapping
	public Map<String, Boolean> doDeleteAction(@PathVariable String id) {
		
		boolean deleteResult = this.boardService.deleteBoardByArticleId(id);
		return Map.of("result", deleteResult);
		
	}
	
	@PreAuthorize("isAuthenticated()")
	@ResponseBody
	@DeleteMapping("/api/articles")
	public Map<String, Boolean> doDeleteAllAction() {
		
		boolean deleteResult = this.boardService.deleteAllBoard();
		return Map.of("result", deleteResult);
	}
	
	@PreAuthorize("isAuthenticated()")
	@ResponseBody
	@PutMapping("/api/article/{articleId}") // 데이터 수정은 Put을 사용
	// UpdateVO에 MultiPartFile이 없는 것 처럼 보이지만 extends한 WriteVO에 존재하기에 RequestBody 사용 불가
	public Map<String, Boolean> doUpdateAction(@PathVariable String articleId,
			UpdateVO updateVO,
			Authentication authentication) {
		
		updateVO.setId(articleId);
		
		MembersVO loginUser = AuthUtils.getPrincipal();
		updateVO.setEmail(loginUser.getEmail());
		
		boolean updateResult = this.boardService.updateBoardByArticleId(updateVO);
		
		return Map.of("result", updateResult);
	}
	
}
