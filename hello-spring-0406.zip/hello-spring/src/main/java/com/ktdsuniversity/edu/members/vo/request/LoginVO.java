package com.ktdsuniversity.edu.members.vo.request;

import jakarta.validation.constraints.NotBlank;

public class LoginVO {

	@NotBlank(message = "이메일을 입력해주세요")
	private String email;
	
	@NotBlank(message = "비밀번호를 입력해주세요")
	private String password;
	
	//사용자 아이피
	private String ip;

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getIp() {
		return ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

}
