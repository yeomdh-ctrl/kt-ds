package com.ktdsuniversity.edu.members.service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ktdsuniversity.edu.members.dao.MembersDao;
import com.ktdsuniversity.edu.members.helpers.SHA256Util;
import com.ktdsuniversity.edu.members.vo.MembersVO;
import com.ktdsuniversity.edu.members.vo.request.LoginVO;
import com.ktdsuniversity.edu.members.vo.request.RegistVO;
import com.ktdsuniversity.edu.members.vo.request.UpdateVO;
import com.ktdsuniversity.edu.members.vo.response.SearchResultVO;

@Service
public class MembersServiceImpl implements MembersService {

	@Autowired
	private MembersDao membersDao;

	@Override
	public boolean createNewMember(RegistVO registVO) {
		MembersVO membersVO = this.membersDao.selectMemberByEmail(registVO.getEmail());
		if (membersVO != null) {
			throw new IllegalArgumentException(registVO.getEmail() + "은 이미 사용중인 이메일입니다.");
		}
		// 암호화를 위한 비밀키 생성
		String newSalt = SHA256Util.generateSalt();
		String usersPassword = registVO.getPassword();

		// 사용자가 입력한 비밀번호를 newSalt를 이용해 암호화
		// 비밀번호와 newSalt의 값이 일치하면, 항상 같은 값의 암호화 결과가 생성된다
		usersPassword = SHA256Util.getEncrypt(usersPassword, newSalt);

		// 비밀키 저장
		registVO.setSalt(newSalt);
		// 암호화된 비밀번호 저장
		registVO.setPassword(usersPassword);

		int insertCount = this.membersDao.insertNewMember(registVO);
		return insertCount == 1;
	}

	@Override
	public MembersVO findMemberByEmail(String email) {
		MembersVO searchResult = this.membersDao.selectMemberByEmail(email);
		return searchResult;
	}

	@Override
	public boolean updateMemberByEmail(UpdateVO updateVO) {
		int updateCount = this.membersDao.updateMemberByEmail(updateVO);
		return updateCount == 1;
	}

	@Override
	public boolean deleteMemberByEmail(String email) {
		int deleteCount = this.membersDao.deleteMemberByEmail(email);
		return deleteCount == 1;
	}

	@Override
	public SearchResultVO findMembersList() {
		SearchResultVO result = new SearchResultVO();
		int searchCount = this.membersDao.selectMembersCount();
		result.setCount(searchCount);

		if (searchCount == 0) {
			return result;
		}

		List<MembersVO> searchResult = this.membersDao.selectMembersList();
		result.setResult(searchResult);

		return result;
	}

	@Override
	public MembersVO findMemberByEmailAndPassword(LoginVO loginVO) {
		MembersVO searchResult = this.membersDao.selectMemberByEmail(loginVO.getEmail());

		if (searchResult == null) {
			throw new IllegalArgumentException("이메일 또는 비밀번호가 잘못되었습니다.");
		}
		if (searchResult.getBlockYn().equals("Y")) {
			// 로그인 Block 된 시간으로 부터 120분이 지나면 다시 로그인 가능한 상태로 변경한다.
			// 이 경우엔 예외를 던지지 않도록 한다.
			String latestLoginFailDate = searchResult.getLatestLoginFailDate();

			DateTimeFormatter dateTimepattern = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
			LocalDateTime latestBlockDateTime = LocalDateTime.parse(latestLoginFailDate, dateTimepattern);
			
			// 마지막 로그인 실패 시간이 현재 시간에서 두시간을 뺀 시간보다 이후라면 아직 두 시간이 경과하지 않은것. -> 예외를 던진다.
			if (latestBlockDateTime.isAfter(LocalDateTime.now().minusMinutes(120))) {
				throw new IllegalArgumentException("이메일 또는 비밀번호가 잘못되었습니다.");
			}

		}
		String inputPassword = loginVO.getPassword();
		String storedSalt = searchResult.getSalt();
		String encryptedPassword = SHA256Util.getEncrypt(inputPassword, storedSalt);
		if (!encryptedPassword.equals(searchResult.getPassword())) {

			// 해당 이메일의 로그인 실패 횟수를 1 증가시키고 최근 로그인 실패 날짜를 현재 날짜와 시간으로 변경
			this.membersDao.updateIncreaseLoginFailCount(loginVO.getEmail());
			// 최근 로그인 실패 횟수가 5 이상이면 blockYn 을 y로 변경
			this.membersDao.updateBlock(loginVO.getEmail());

			throw new IllegalArgumentException("이메일 또는 비밀번호가 잘못되었습니다.");
		}
		// 로그인 성공 처리
		// 1. login_fail_count 를 0으로 초기와
		// 2. latest_login_ip 를 현재 아이피로 변경
		// 3. login_date를 현재 시간으로 변경
		// 4. block_yn을 'N'으로 변경
		this.membersDao.updateSuccessLogin(loginVO);

		return searchResult;
	}

}
